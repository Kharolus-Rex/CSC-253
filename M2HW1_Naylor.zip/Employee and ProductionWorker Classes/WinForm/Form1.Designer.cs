﻿namespace WinForm
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.createWorkerButton = new System.Windows.Forms.Button();
            this.employeeNameLabel = new System.Windows.Forms.Label();
            this.employeeIdLabel = new System.Windows.Forms.Label();
            this.employeeShiftLabel = new System.Windows.Forms.Label();
            this.employeePayLabel = new System.Windows.Forms.Label();
            this.employeeNameTextBox = new System.Windows.Forms.TextBox();
            this.employeeIdTextBox = new System.Windows.Forms.TextBox();
            this.employeeShiftTextBox = new System.Windows.Forms.TextBox();
            this.employeePayTextBox = new System.Windows.Forms.TextBox();
            this.displayButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.instructionsLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // createWorkerButton
            // 
            this.createWorkerButton.Location = new System.Drawing.Point(108, 245);
            this.createWorkerButton.Name = "createWorkerButton";
            this.createWorkerButton.Size = new System.Drawing.Size(75, 23);
            this.createWorkerButton.TabIndex = 0;
            this.createWorkerButton.Text = "Create";
            this.createWorkerButton.UseVisualStyleBackColor = true;
            this.createWorkerButton.Click += new System.EventHandler(this.createWorkerButton_Click);
            // 
            // employeeNameLabel
            // 
            this.employeeNameLabel.AutoSize = true;
            this.employeeNameLabel.Location = new System.Drawing.Point(105, 111);
            this.employeeNameLabel.Name = "employeeNameLabel";
            this.employeeNameLabel.Size = new System.Drawing.Size(84, 13);
            this.employeeNameLabel.TabIndex = 1;
            this.employeeNameLabel.Text = "Employee Name";
            // 
            // employeeIdLabel
            // 
            this.employeeIdLabel.AutoSize = true;
            this.employeeIdLabel.Location = new System.Drawing.Point(122, 138);
            this.employeeIdLabel.Name = "employeeIdLabel";
            this.employeeIdLabel.Size = new System.Drawing.Size(67, 13);
            this.employeeIdLabel.TabIndex = 2;
            this.employeeIdLabel.Text = "Employee ID";
            // 
            // employeeShiftLabel
            // 
            this.employeeShiftLabel.AutoSize = true;
            this.employeeShiftLabel.Location = new System.Drawing.Point(161, 164);
            this.employeeShiftLabel.Name = "employeeShiftLabel";
            this.employeeShiftLabel.Size = new System.Drawing.Size(28, 13);
            this.employeeShiftLabel.TabIndex = 3;
            this.employeeShiftLabel.Text = "Shift";
            // 
            // employeePayLabel
            // 
            this.employeePayLabel.AutoSize = true;
            this.employeePayLabel.Location = new System.Drawing.Point(126, 190);
            this.employeePayLabel.Name = "employeePayLabel";
            this.employeePayLabel.Size = new System.Drawing.Size(63, 13);
            this.employeePayLabel.TabIndex = 4;
            this.employeePayLabel.Text = "Hourly Rate";
            // 
            // employeeNameTextBox
            // 
            this.employeeNameTextBox.Location = new System.Drawing.Point(195, 108);
            this.employeeNameTextBox.Name = "employeeNameTextBox";
            this.employeeNameTextBox.Size = new System.Drawing.Size(100, 20);
            this.employeeNameTextBox.TabIndex = 5;
            // 
            // employeeIdTextBox
            // 
            this.employeeIdTextBox.Location = new System.Drawing.Point(195, 134);
            this.employeeIdTextBox.Name = "employeeIdTextBox";
            this.employeeIdTextBox.Size = new System.Drawing.Size(100, 20);
            this.employeeIdTextBox.TabIndex = 6;
            // 
            // employeeShiftTextBox
            // 
            this.employeeShiftTextBox.Location = new System.Drawing.Point(195, 161);
            this.employeeShiftTextBox.Name = "employeeShiftTextBox";
            this.employeeShiftTextBox.Size = new System.Drawing.Size(100, 20);
            this.employeeShiftTextBox.TabIndex = 7;
            // 
            // employeePayTextBox
            // 
            this.employeePayTextBox.Location = new System.Drawing.Point(195, 187);
            this.employeePayTextBox.Name = "employeePayTextBox";
            this.employeePayTextBox.Size = new System.Drawing.Size(100, 20);
            this.employeePayTextBox.TabIndex = 8;
            // 
            // displayButton
            // 
            this.displayButton.Location = new System.Drawing.Point(220, 245);
            this.displayButton.Name = "displayButton";
            this.displayButton.Size = new System.Drawing.Size(75, 23);
            this.displayButton.TabIndex = 9;
            this.displayButton.Text = "Display";
            this.displayButton.UseVisualStyleBackColor = true;
            this.displayButton.Click += new System.EventHandler(this.displayButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(164, 290);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 10;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // instructionsLabel
            // 
            this.instructionsLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.instructionsLabel.Location = new System.Drawing.Point(108, 32);
            this.instructionsLabel.Name = "instructionsLabel";
            this.instructionsLabel.Size = new System.Drawing.Size(187, 55);
            this.instructionsLabel.TabIndex = 11;
            this.instructionsLabel.Text = "Please enter new employee information and click Create. Click display after to ve" +
    "rify information.";
            this.instructionsLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(409, 348);
            this.Controls.Add(this.instructionsLabel);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.displayButton);
            this.Controls.Add(this.employeePayTextBox);
            this.Controls.Add(this.employeeShiftTextBox);
            this.Controls.Add(this.employeeIdTextBox);
            this.Controls.Add(this.employeeNameTextBox);
            this.Controls.Add(this.employeePayLabel);
            this.Controls.Add(this.employeeShiftLabel);
            this.Controls.Add(this.employeeIdLabel);
            this.Controls.Add(this.employeeNameLabel);
            this.Controls.Add(this.createWorkerButton);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button createWorkerButton;
        private System.Windows.Forms.Label employeeNameLabel;
        private System.Windows.Forms.Label employeeIdLabel;
        private System.Windows.Forms.Label employeeShiftLabel;
        private System.Windows.Forms.Label employeePayLabel;
        private System.Windows.Forms.TextBox employeeNameTextBox;
        private System.Windows.Forms.TextBox employeeIdTextBox;
        private System.Windows.Forms.TextBox employeeShiftTextBox;
        private System.Windows.Forms.TextBox employeePayTextBox;
        private System.Windows.Forms.Button displayButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Label instructionsLabel;
    }
}

