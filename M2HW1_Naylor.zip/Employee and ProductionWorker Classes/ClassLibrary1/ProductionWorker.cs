﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public class ProductionWorker : Employee
    {
        private int _shift;
        private double _pay;

        public ProductionWorker(string name, int id, int shift, double pay) : base(name, id)
        {
            Shift = shift;
            Pay = pay;
        }

        public int Shift { get { return _shift; } set { _shift = value; } }
        public double Pay { get { return _pay; } set { _pay = value; } }
    }
}
