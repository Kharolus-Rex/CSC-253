﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public class CreationMethods
    { 
        public static ProductionWorker CreateWorker(string name, int id, int shift, double pay)
        {
            //initialize into blanks and 0's. will be filled in through method.
            ProductionWorker CurrentWorker = new ProductionWorker("",0,0,0);

            //set information for CurrentWorker
            CurrentWorker.Name = name;
            CurrentWorker.Id = id;
            CurrentWorker.Shift = shift;
            CurrentWorker.Pay = pay;

            return CurrentWorker;
        }

    }
}
