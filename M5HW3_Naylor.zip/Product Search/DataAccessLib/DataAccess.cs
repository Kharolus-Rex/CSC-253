﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLib
{
    public class DataAccess
    {
        //This first method will be for searching via product number
        public static List<Product> ProductIDSearch(string productID)
        {
            //bring datacontext in
            SQLinkDataContext db = new SQLinkDataContext();
            var results = from Product in db.Products
                          where Product.Product_Number == productID
                          select Product;
            return results.ToList();
        }

        //this method will be for searching the descriptions for specific text
        public static List<Product> ProductDescripSearch(string productDescrip)
        {
            SQLinkDataContext db = new SQLinkDataContext();
            var results = from Product in db.Products
                          where Product.Description.Contains(productDescrip)
                          select Product;
            return results.ToList();
        }
    }
}
