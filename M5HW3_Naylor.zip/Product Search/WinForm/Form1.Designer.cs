﻿namespace WinForm
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.productListBox = new System.Windows.Forms.ListBox();
            this.inputTextBox = new System.Windows.Forms.TextBox();
            this.searchByIDButton = new System.Windows.Forms.Button();
            this.searchByDescriptionButton = new System.Windows.Forms.Button();
            this.instructionsLabel = new System.Windows.Forms.Label();
            this.exitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // productListBox
            // 
            this.productListBox.FormattingEnabled = true;
            this.productListBox.Location = new System.Drawing.Point(234, 72);
            this.productListBox.Name = "productListBox";
            this.productListBox.Size = new System.Drawing.Size(543, 199);
            this.productListBox.TabIndex = 0;
            // 
            // inputTextBox
            // 
            this.inputTextBox.Location = new System.Drawing.Point(76, 150);
            this.inputTextBox.Name = "inputTextBox";
            this.inputTextBox.Size = new System.Drawing.Size(100, 20);
            this.inputTextBox.TabIndex = 1;
            // 
            // searchByIDButton
            // 
            this.searchByIDButton.Location = new System.Drawing.Point(82, 173);
            this.searchByIDButton.Name = "searchByIDButton";
            this.searchByIDButton.Size = new System.Drawing.Size(88, 23);
            this.searchByIDButton.TabIndex = 2;
            this.searchByIDButton.Text = "Search by ID";
            this.searchByIDButton.UseVisualStyleBackColor = true;
            this.searchByIDButton.Click += new System.EventHandler(this.searchByIDButton_Click);
            // 
            // searchByDescriptionButton
            // 
            this.searchByDescriptionButton.Location = new System.Drawing.Point(65, 200);
            this.searchByDescriptionButton.Name = "searchByDescriptionButton";
            this.searchByDescriptionButton.Size = new System.Drawing.Size(123, 23);
            this.searchByDescriptionButton.TabIndex = 3;
            this.searchByDescriptionButton.Text = "Search by Description";
            this.searchByDescriptionButton.UseVisualStyleBackColor = true;
            this.searchByDescriptionButton.Click += new System.EventHandler(this.searchByDescriptionButton_Click);
            // 
            // instructionsLabel
            // 
            this.instructionsLabel.Location = new System.Drawing.Point(46, 87);
            this.instructionsLabel.Name = "instructionsLabel";
            this.instructionsLabel.Size = new System.Drawing.Size(159, 60);
            this.instructionsLabel.TabIndex = 4;
            this.instructionsLabel.Text = "Input a product ID or description text and click the appropriate button.\r\n";
            this.instructionsLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(88, 228);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 5;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(947, 356);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.instructionsLabel);
            this.Controls.Add(this.searchByDescriptionButton);
            this.Controls.Add(this.searchByIDButton);
            this.Controls.Add(this.inputTextBox);
            this.Controls.Add(this.productListBox);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox productListBox;
        private System.Windows.Forms.TextBox inputTextBox;
        private System.Windows.Forms.Button searchByIDButton;
        private System.Windows.Forms.Button searchByDescriptionButton;
        private System.Windows.Forms.Label instructionsLabel;
        private System.Windows.Forms.Button exitButton;
    }
}

