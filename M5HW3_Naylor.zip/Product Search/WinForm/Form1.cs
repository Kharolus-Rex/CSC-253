﻿/**
* 11-24-23
* CSC 253
* Connor Naylor
* This program uses LINQ to access a database and
* allows the user to serach the table by product ID
* or by a partial description.
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DataAccessLib;

namespace WinForm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void searchByIDButton_Click(object sender, EventArgs e)
        {
            List<Product> prodList = new List<Product>();
            string searchID = inputTextBox.Text;
            prodList = DataAccess.ProductIDSearch(searchID);
            inputTextBox.Clear();
            productListBox.Items.Clear();
            //maybe there's an easier way to add exactly what I want. but I'm unsure off the top of my head, so back to basics.
            foreach (Product prod in prodList)
            {
                productListBox.Items.Add($"Product Number: {prod.Product_Number} | Description: {prod.Description} | Units on Hand: {prod.Units_On_Hand} | Price: {prod.Price}");
            }
        }

        private void searchByDescriptionButton_Click(object sender, EventArgs e)
        {
            List<Product> prodList = new List<Product>();
            string searchDesc = inputTextBox.Text;
            prodList = DataAccess.ProductDescripSearch(searchDesc);
            inputTextBox.Clear();
            productListBox.Items.Clear();
            foreach (Product prod in prodList)
            {
                productListBox.Items.Add($"Product Number: {prod.Product_Number} | Description: {prod.Description} | Units on Hand: {prod.Units_On_Hand} | Price: {prod.Price}");
            }
        }
    }
}
