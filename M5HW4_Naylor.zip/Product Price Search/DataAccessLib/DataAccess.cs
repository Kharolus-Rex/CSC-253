﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Security.Policy;

namespace DataAccessLib
{
    public class DataAccess
    {      
        //filter method
        //had to google and figure out what 'money' value type is parsed as from SQL to .NET. it's decimal.
        public static List<Product> minMaxFilter(decimal min, decimal max)
        {
            SQLinkDataContext db = new SQLinkDataContext();
            var results = from Product in db.Products
                          where Product.Price >= min && Product.Price <= max
                          select Product;
            return results.ToList();
        }

        public static List<Product> listLoading()
        {
            //this should select all products for the list
            SQLinkDataContext db = new SQLinkDataContext();
            var results = from Product in db.Products
                          select Product;
            return results.ToList();
        }
    }
}
