﻿/**
* 11-24-23
* CSC 253
* Connor Naylor
* This program uses LINQ to access a database and
* allows the user to serach the table by inputting
* a min and max cost to filter by.
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DataAccessLib;

namespace WinForm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            loadProductListBox();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void filterButton_Click(object sender, EventArgs e)
        {
            List<Product> prodList = new List<Product>();
            decimal minPrice = decimal.Parse(minPriceTextBox.Text);
            decimal maxPrice = decimal.Parse(maxPriceTextBox.Text);
            prodList = DataAccess.minMaxFilter(minPrice, maxPrice);
            productListBox.Items.Clear();
            foreach (Product prod in prodList)
            {
                productListBox.Items.Add($"Product Number: {prod.Product_Number} | Description: {prod.Description} | Units on Hand: {prod.Units_On_Hand} | Price: {prod.Price}");
            }
        }

        private void loadProductListBox()
        {
            List<Product> prodList = new List<Product>();
            prodList = DataAccess.listLoading();
            productListBox.Items.Clear();
            foreach (Product prod in prodList)
            {
                productListBox.Items.Add($"Product Number: {prod.Product_Number} | Description: {prod.Description} | Units on Hand: {prod.Units_On_Hand} | Price: {prod.Price}");
            }
        }

    }
}
