﻿/**
* 9/16/23
* CSC 253
* Connor Naylor
* This program takes an input file and asks user to
* generate an output file. The program then indexes
* each of the words within the input file and lists them
* in alphabetical order and on what lines they appear in
* the output file.
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ProcessMethods;

namespace WinForm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void processButton_Click(object sender, EventArgs e)
        {
            //allows file paths to be passed to methods
            string inputFilePath, outputFilePath;

            openFileDialog1.ShowDialog();

            inputFilePath = openFileDialog1.FileName.ToString();

            saveFileDialog1.ShowDialog();

            outputFilePath = saveFileDialog1.FileName.ToString();

            Processing.Process(inputFilePath, outputFilePath);

            MessageBox.Show($"Word index generated as {saveFileDialog1.FileName}");

        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
