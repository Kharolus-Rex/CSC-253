﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProcessMethods
{
    public class Processing
    {
        public static void Process(string inputFile, string outputFile)
        {
            //create dictionary to store new words as file is read
            Dictionary<string, List<int>> wordIndex = new Dictionary<string, List<int>>();

            //read file line by line
            string[] lines = File.ReadAllLines(inputFile);

            for (int lineNumber = 0; lineNumber < lines.Length; lineNumber++)
            {
                //splits up each line
                string line = lines[lineNumber];
                string[] words = line.Split(new char[] {' ', '.', ',', ';', ':', '!', '?'}, StringSplitOptions.RemoveEmptyEntries);

                foreach (string word in words)
                {
                    string cleanedWord = word.ToLower(); //keep it all lowecase for simplicity

                    if (!wordIndex.ContainsKey(cleanedWord))
                    {
                        //adds each new word to the Dictionary
                        wordIndex[cleanedWord] = new List<int>();
                    }

                    wordIndex[cleanedWord].Add(lineNumber + 1);
                }

                //sort Dictionary to be aplphabetical. won't lie, had to look this one up.
                var sortedWordIndex = wordIndex.OrderBy(pair => pair.Key);

                //create output file containing index
                using (StreamWriter writer = new StreamWriter(outputFile))
                {
                    foreach (var entry in sortedWordIndex)
                    {
                        string lineNumbers = string.Join(", ", entry.Value);
                        writer.WriteLine($"{entry.Key}: {lineNumbers}");
                    }
                    writer.Close();
                }

            }
            return;
        }
    }
}
