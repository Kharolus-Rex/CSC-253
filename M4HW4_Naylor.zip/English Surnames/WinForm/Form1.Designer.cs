﻿namespace WinForm
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.surnameListBox = new System.Windows.Forms.ListBox();
            this.findLongerButton = new System.Windows.Forms.Button();
            this.findShorterButton = new System.Windows.Forms.Button();
            this.findStartingWithButton = new System.Windows.Forms.Button();
            this.findMatchButton = new System.Windows.Forms.Button();
            this.resetButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.instructionsLabel = new System.Windows.Forms.Label();
            this.queryTextBox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // surnameListBox
            // 
            this.surnameListBox.FormattingEnabled = true;
            this.surnameListBox.Location = new System.Drawing.Point(320, 50);
            this.surnameListBox.Name = "surnameListBox";
            this.surnameListBox.Size = new System.Drawing.Size(209, 173);
            this.surnameListBox.TabIndex = 0;
            // 
            // findLongerButton
            // 
            this.findLongerButton.Location = new System.Drawing.Point(82, 130);
            this.findLongerButton.Name = "findLongerButton";
            this.findLongerButton.Size = new System.Drawing.Size(75, 23);
            this.findLongerButton.TabIndex = 1;
            this.findLongerButton.Text = "Find Longer";
            this.findLongerButton.UseVisualStyleBackColor = true;
            this.findLongerButton.Click += new System.EventHandler(this.findLongerButton_Click);
            // 
            // findShorterButton
            // 
            this.findShorterButton.Location = new System.Drawing.Point(163, 130);
            this.findShorterButton.Name = "findShorterButton";
            this.findShorterButton.Size = new System.Drawing.Size(75, 23);
            this.findShorterButton.TabIndex = 2;
            this.findShorterButton.Text = "Find Shorter";
            this.findShorterButton.UseVisualStyleBackColor = true;
            this.findShorterButton.Click += new System.EventHandler(this.findShorterButton_Click);
            // 
            // findStartingWithButton
            // 
            this.findStartingWithButton.Location = new System.Drawing.Point(103, 161);
            this.findStartingWithButton.Name = "findStartingWithButton";
            this.findStartingWithButton.Size = new System.Drawing.Size(112, 23);
            this.findStartingWithButton.TabIndex = 3;
            this.findStartingWithButton.Text = "Find Starting With";
            this.findStartingWithButton.UseVisualStyleBackColor = true;
            this.findStartingWithButton.Click += new System.EventHandler(this.findStartingWithButton_Click);
            // 
            // findMatchButton
            // 
            this.findMatchButton.Location = new System.Drawing.Point(115, 190);
            this.findMatchButton.Name = "findMatchButton";
            this.findMatchButton.Size = new System.Drawing.Size(91, 23);
            this.findMatchButton.TabIndex = 4;
            this.findMatchButton.Text = "Find Matching";
            this.findMatchButton.UseVisualStyleBackColor = true;
            this.findMatchButton.Click += new System.EventHandler(this.findMatchButton_Click);
            // 
            // resetButton
            // 
            this.resetButton.Location = new System.Drawing.Point(82, 220);
            this.resetButton.Name = "resetButton";
            this.resetButton.Size = new System.Drawing.Size(75, 23);
            this.resetButton.TabIndex = 5;
            this.resetButton.Text = "Reset";
            this.resetButton.UseVisualStyleBackColor = true;
            this.resetButton.Click += new System.EventHandler(this.resetButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(163, 219);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 6;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // instructionsLabel
            // 
            this.instructionsLabel.Location = new System.Drawing.Point(45, 24);
            this.instructionsLabel.Name = "instructionsLabel";
            this.instructionsLabel.Size = new System.Drawing.Size(256, 77);
            this.instructionsLabel.TabIndex = 7;
            this.instructionsLabel.Text = resources.GetString("instructionsLabel.Text");
            this.instructionsLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // queryTextBox
            // 
            this.queryTextBox.Location = new System.Drawing.Point(115, 104);
            this.queryTextBox.Name = "queryTextBox";
            this.queryTextBox.Size = new System.Drawing.Size(100, 20);
            this.queryTextBox.TabIndex = 8;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(605, 322);
            this.Controls.Add(this.queryTextBox);
            this.Controls.Add(this.instructionsLabel);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.resetButton);
            this.Controls.Add(this.findMatchButton);
            this.Controls.Add(this.findStartingWithButton);
            this.Controls.Add(this.findShorterButton);
            this.Controls.Add(this.findLongerButton);
            this.Controls.Add(this.surnameListBox);
            this.Name = "Form1";
            this.Text = "English Surnames";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox surnameListBox;
        private System.Windows.Forms.Button findLongerButton;
        private System.Windows.Forms.Button findShorterButton;
        private System.Windows.Forms.Button findStartingWithButton;
        private System.Windows.Forms.Button findMatchButton;
        private System.Windows.Forms.Button resetButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Label instructionsLabel;
        private System.Windows.Forms.TextBox queryTextBox;
    }
}

