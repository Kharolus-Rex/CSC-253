﻿/**
* 11/5/23
* CSC 253
* Connor Naylor
* This program loads a list of surnames. The user may then
* input a number or string to look for surnames longer or shorter
* than the number OR starting with or an exact match to the string.
* Also comes with a reset button.
*/

using MethodsNMadness;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinForm
{
    public partial class Form1 : Form
    {
        public List<string> nameList = new List<string>();

        public List<string> updatedList = new List<string>();
        public Form1()
        {
            InitializeComponent();

            LoadNameList();

            updatedList.Clear(); //just to make sure the list is empty at start
        }

        private void LoadNameList()
        {
            nameList = Methodology.LoadNameList();

            LoadListBox(nameList);
        }

        private void LoadListBox(List<string> list)
            //set up to allow different lists to be loaded, based on button press
        {
            surnameListBox.Items.Clear();

            foreach (var name in list)
            {
                string surname = name.ToString();

                surnameListBox.Items.Add(surname);
            }
        }

        private void findLongerButton_Click(object sender, EventArgs e)
        {
            int length = int.Parse(queryTextBox.Text);

            updatedList = Methodology.FindLongerNames(nameList, length);

            LoadListBox(updatedList);

            updatedList.Clear();
        }

        private void findShorterButton_Click(object sender, EventArgs e)
        {
            int length = int.Parse(queryTextBox.Text);

            updatedList = Methodology.FindShorterNames(nameList, length);

            LoadListBox(updatedList);

            updatedList.Clear();
        }

        private void findStartingWithButton_Click(object sender, EventArgs e)
        {
            string starting = queryTextBox.Text.ToString();

            updatedList = Methodology.FindStartingMatch(nameList, starting);

            LoadListBox(updatedList);

            updatedList.Clear();
        }

        private void findMatchButton_Click(object sender, EventArgs e)
        {
            string match = queryTextBox.Text.ToString();

            updatedList = Methodology.FindExactMatch(nameList, match);

            LoadListBox(updatedList);

            updatedList.Clear();
        }

        private void resetButton_Click(object sender, EventArgs e)
        {
            LoadNameList();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
