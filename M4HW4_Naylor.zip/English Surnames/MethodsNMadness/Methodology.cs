﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace MethodsNMadness
{
    public class Methodology
    {
        public static List<string> LoadNameList()
        {
            List<string> nameList = new List<string>();

            using (var reader = new StreamReader(@"..\..\..\MethodsNMadness\surnames.txt"))
            {
                while (!reader.EndOfStream)
                {
                    var name = reader.ReadLine();

                    nameList.Add(name);
                }
            }

            return nameList;

        }

        public static List<string> FindLongerNames(List<string> surnames, int length)
        {
            //lambda really does shorten this up, doesn't it?
            return surnames.Where(surname => surname.Length > length).ToList();
        }

        public static List<string> FindShorterNames(List<string> surnames, int length)
        {
            return surnames.Where(surname => surname.Length < length).ToList();
        }

        public static List<string> FindStartingMatch(List<string> surnames, string prefix)
        {
            return surnames.Where(surname => surname.StartsWith(prefix, StringComparison.OrdinalIgnoreCase)).ToList();
        }

        public static List<string> FindExactMatch(List<string> surnames, string name)
        {
            //case ignore to allow user to type as they please
            return surnames.Where(surname => surname.Equals(name, StringComparison.OrdinalIgnoreCase)).ToList();
        }
    }
}
