﻿/**
* 11/5/23
* CSC 253
* Connor Naylor
* This program is a simple prime number calculator.
* It will take user input and find all prime numbers
* between 1 and input and display all primes.
*/
using MethodsNMadness;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinForm
{
    public partial class Form1 : Form
    {
        //generates an empty list
        public List<int> primeNumbers = new List<int>();
        public Form1()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void LoadListBox(List<int> list)
        {
            primeListBox.Items.Clear();

            foreach (var item in list)
            {
                primeListBox.Items.Add(item);
            }

            //clear list in case user wants to run multiple times
            primeNumbers.Clear();
        }

        private void generateButton_Click(object sender, EventArgs e)
        {
            int number = int.Parse(queryTextBox.Text);

            if (number >= 2)
            {
                primeNumbers = Numerics.GeneratePrimeList(number);
            }
            else
            {
                MessageBox.Show("Number is not greater than 1!");
            }

            LoadListBox(primeNumbers);
        }
    }
}
