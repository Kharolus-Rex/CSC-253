﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MethodsNMadness
{
    public class Numerics
    {
        public delegate bool IsPrimeDelegate(int number);
        public static List<int> GeneratePrimeList(int input)
        {
            IsPrimeDelegate isPrime = n =>
            {
                //initial checks to verify if prime or not
                if (n <= 1)
                {
                    return false;
                }
                if (n <= 3)
                {
                    return true;
                }
                if (n % 2 == 0 || n % 3 == 0)
                {
                    return false;
                }
                //did some research on prime number verification efficiency, cause why divide by all when there's better options?
                for (int i = 5; i * i <= n; i += 6)
                {
                    if (n % i == 0 || n % (i + 2) == 0)
                    {
                        return false;
                    }
                }
                return true;
            };

            //generate initial list using built-in methods
            List<int> numbers = Enumerable.Range(1, input).ToList();
            //generate prime number list via lambda expression
            List<int> primeNumbers = numbers.FindAll(n => isPrime(n));

            return primeNumbers;
        }
    }
}
