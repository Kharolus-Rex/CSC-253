﻿/**
* 10/22/23
* CSC 253
* Connor Naylor
* This iteration of the program allows the user to filter
* the display of the highest or lowest pay in the database.
*/

using MethodCalls;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinForm
{
    public partial class Form1 : Form
    {

        List<EmployeeModel> employee = new List<EmployeeModel>();

        public Form1()
        {
            InitializeComponent();

            LoadEmployeeList();
        }

        private void LoadEmployeeList()
        {
            employee = SqliteDataAccess.LoadEmployees();

            LoadDataGrid();
        }

        private void LoadDataGrid()
        {
            //empty the datasource first and then load
            employeeDataGridView.DataSource = null;
            employeeDataGridView.DataSource = employee;
            
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void highestPayButton_Click(object sender, EventArgs e)
        {
            List<EmployeeModel> highest = SqliteDataAccess.HighestPay();
            employeeDataGridView.DataSource = highest;
        }

        private void lowestButton_Click(object sender, EventArgs e)
        {
            List<EmployeeModel> lowest= SqliteDataAccess.LowestPay();
            employeeDataGridView.DataSource= lowest;
        }

        private void resetButton_Click(object sender, EventArgs e)
        {
            employeeDataGridView.DataSource = employee;
        }
    }
}
