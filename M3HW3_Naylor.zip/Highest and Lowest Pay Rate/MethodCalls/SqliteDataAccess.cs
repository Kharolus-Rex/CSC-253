﻿using Dapper;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SQLite;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MethodCalls
{
    public class SqliteDataAccess
    {
        public static List<EmployeeModel> LoadEmployees()
        {
            using (IDbConnection cnn = new SQLiteConnection(LoadConnectionString()))
            {
                var output = cnn.Query<EmployeeModel>("select * from Employee", new DynamicParameters());
                return output.ToList();
            }
        }


        private static string LoadConnectionString(String id = "Default")
        {
            return ConfigurationManager.ConnectionStrings[id].ConnectionString;
        }

        public static List<EmployeeModel> HighestPay()
        {
            using (IDbConnection cnn = new SQLiteConnection(LoadConnectionString()))
            {
                var output = cnn.Query<EmployeeModel>("select * from Employee where hourly = (select max(hourly) from Employee)");
                return output.ToList();
            }
        }

        public static List<EmployeeModel> LowestPay()
        {
            using (IDbConnection cnn = new SQLiteConnection(LoadConnectionString()))
            {
                var output = cnn.Query<EmployeeModel>("select * from Employee where hourly = (select min(hourly) from Employee)");
                return output.ToList();
            }
        }
    }
}
