﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MethodCalls
{
    public class EmployeeModel
    {
        private int _id;
        private string _name;
        private string _position;
        private double _hourly;

        public EmployeeModel()
        {

        }

        public EmployeeModel(int id, string name, string position, double hourly)
        {
            Id = id;
            Name = name;
            Position = position;
            Hourly = hourly;
        }

        public int Id { get { return _id; } set { _id = value; } }
        public string Name { get { return _name; } set { _name = value; } }
        public string Position { get { return _position; } set { _position = value; } }
        public double Hourly { get { return _hourly; } set { _hourly = value; } }
    }

}