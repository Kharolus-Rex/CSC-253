﻿namespace WinForm
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.createWorkerButton = new System.Windows.Forms.Button();
            this.employeeNameLabel = new System.Windows.Forms.Label();
            this.employeeIdLabel = new System.Windows.Forms.Label();
            this.employeeShiftLabel = new System.Windows.Forms.Label();
            this.employeePayLabel = new System.Windows.Forms.Label();
            this.employeeNameTextBox = new System.Windows.Forms.TextBox();
            this.employeeIdTextBox = new System.Windows.Forms.TextBox();
            this.employeeShiftTextBox = new System.Windows.Forms.TextBox();
            this.employeePayTextBox = new System.Windows.Forms.TextBox();
            this.displayButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.instructionsLabel = new System.Windows.Forms.Label();
            this.leaderMonthBonusLabel = new System.Windows.Forms.Label();
            this.leaderMonthBonusTextBox = new System.Windows.Forms.TextBox();
            this.reqTrainingHoursLabel = new System.Windows.Forms.Label();
            this.reqTrainingHoursTextBox = new System.Windows.Forms.TextBox();
            this.currentTrainingHoursLabel = new System.Windows.Forms.Label();
            this.currTrainingHoursTextBox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // createWorkerButton
            // 
            this.createWorkerButton.Location = new System.Drawing.Point(108, 318);
            this.createWorkerButton.Name = "createWorkerButton";
            this.createWorkerButton.Size = new System.Drawing.Size(75, 23);
            this.createWorkerButton.TabIndex = 12;
            this.createWorkerButton.Text = "Create";
            this.createWorkerButton.UseVisualStyleBackColor = true;
            this.createWorkerButton.Click += new System.EventHandler(this.createWorkerButton_Click);
            // 
            // employeeNameLabel
            // 
            this.employeeNameLabel.AutoSize = true;
            this.employeeNameLabel.Location = new System.Drawing.Point(105, 111);
            this.employeeNameLabel.Name = "employeeNameLabel";
            this.employeeNameLabel.Size = new System.Drawing.Size(84, 13);
            this.employeeNameLabel.TabIndex = 1;
            this.employeeNameLabel.Text = "Employee Name";
            // 
            // employeeIdLabel
            // 
            this.employeeIdLabel.AutoSize = true;
            this.employeeIdLabel.Location = new System.Drawing.Point(122, 138);
            this.employeeIdLabel.Name = "employeeIdLabel";
            this.employeeIdLabel.Size = new System.Drawing.Size(67, 13);
            this.employeeIdLabel.TabIndex = 2;
            this.employeeIdLabel.Text = "Employee ID";
            // 
            // employeeShiftLabel
            // 
            this.employeeShiftLabel.AutoSize = true;
            this.employeeShiftLabel.Location = new System.Drawing.Point(161, 164);
            this.employeeShiftLabel.Name = "employeeShiftLabel";
            this.employeeShiftLabel.Size = new System.Drawing.Size(28, 13);
            this.employeeShiftLabel.TabIndex = 3;
            this.employeeShiftLabel.Text = "Shift";
            // 
            // employeePayLabel
            // 
            this.employeePayLabel.AutoSize = true;
            this.employeePayLabel.Location = new System.Drawing.Point(126, 190);
            this.employeePayLabel.Name = "employeePayLabel";
            this.employeePayLabel.Size = new System.Drawing.Size(63, 13);
            this.employeePayLabel.TabIndex = 4;
            this.employeePayLabel.Text = "Hourly Rate";
            // 
            // employeeNameTextBox
            // 
            this.employeeNameTextBox.Location = new System.Drawing.Point(195, 108);
            this.employeeNameTextBox.Name = "employeeNameTextBox";
            this.employeeNameTextBox.Size = new System.Drawing.Size(100, 20);
            this.employeeNameTextBox.TabIndex = 5;
            // 
            // employeeIdTextBox
            // 
            this.employeeIdTextBox.Location = new System.Drawing.Point(195, 134);
            this.employeeIdTextBox.Name = "employeeIdTextBox";
            this.employeeIdTextBox.Size = new System.Drawing.Size(100, 20);
            this.employeeIdTextBox.TabIndex = 6;
            // 
            // employeeShiftTextBox
            // 
            this.employeeShiftTextBox.Location = new System.Drawing.Point(195, 161);
            this.employeeShiftTextBox.Name = "employeeShiftTextBox";
            this.employeeShiftTextBox.Size = new System.Drawing.Size(100, 20);
            this.employeeShiftTextBox.TabIndex = 7;
            // 
            // employeePayTextBox
            // 
            this.employeePayTextBox.Location = new System.Drawing.Point(195, 187);
            this.employeePayTextBox.Name = "employeePayTextBox";
            this.employeePayTextBox.Size = new System.Drawing.Size(100, 20);
            this.employeePayTextBox.TabIndex = 8;
            // 
            // displayButton
            // 
            this.displayButton.Location = new System.Drawing.Point(220, 318);
            this.displayButton.Name = "displayButton";
            this.displayButton.Size = new System.Drawing.Size(75, 23);
            this.displayButton.TabIndex = 13;
            this.displayButton.Text = "Display";
            this.displayButton.UseVisualStyleBackColor = true;
            this.displayButton.Click += new System.EventHandler(this.displayButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(164, 363);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 14;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // instructionsLabel
            // 
            this.instructionsLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.instructionsLabel.Location = new System.Drawing.Point(108, 32);
            this.instructionsLabel.Name = "instructionsLabel";
            this.instructionsLabel.Size = new System.Drawing.Size(187, 55);
            this.instructionsLabel.TabIndex = 11;
            this.instructionsLabel.Text = "Please enter new team leader information and click Create. Click display after to" +
    " verify information.";
            this.instructionsLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // leaderMonthBonusLabel
            // 
            this.leaderMonthBonusLabel.AutoSize = true;
            this.leaderMonthBonusLabel.Location = new System.Drawing.Point(112, 217);
            this.leaderMonthBonusLabel.Name = "leaderMonthBonusLabel";
            this.leaderMonthBonusLabel.Size = new System.Drawing.Size(77, 13);
            this.leaderMonthBonusLabel.TabIndex = 12;
            this.leaderMonthBonusLabel.Text = "Monthly Bonus";
            // 
            // leaderMonthBonusTextBox
            // 
            this.leaderMonthBonusTextBox.Location = new System.Drawing.Point(195, 214);
            this.leaderMonthBonusTextBox.Name = "leaderMonthBonusTextBox";
            this.leaderMonthBonusTextBox.Size = new System.Drawing.Size(100, 20);
            this.leaderMonthBonusTextBox.TabIndex = 9;
            // 
            // reqTrainingHoursLabel
            // 
            this.reqTrainingHoursLabel.AutoSize = true;
            this.reqTrainingHoursLabel.Location = new System.Drawing.Point(67, 246);
            this.reqTrainingHoursLabel.Name = "reqTrainingHoursLabel";
            this.reqTrainingHoursLabel.Size = new System.Drawing.Size(122, 13);
            this.reqTrainingHoursLabel.TabIndex = 14;
            this.reqTrainingHoursLabel.Text = "Required Training Hours";
            // 
            // reqTrainingHoursTextBox
            // 
            this.reqTrainingHoursTextBox.Location = new System.Drawing.Point(195, 243);
            this.reqTrainingHoursTextBox.Name = "reqTrainingHoursTextBox";
            this.reqTrainingHoursTextBox.Size = new System.Drawing.Size(100, 20);
            this.reqTrainingHoursTextBox.TabIndex = 10;
            // 
            // currentTrainingHoursLabel
            // 
            this.currentTrainingHoursLabel.AutoSize = true;
            this.currentTrainingHoursLabel.Location = new System.Drawing.Point(76, 273);
            this.currentTrainingHoursLabel.Name = "currentTrainingHoursLabel";
            this.currentTrainingHoursLabel.Size = new System.Drawing.Size(113, 13);
            this.currentTrainingHoursLabel.TabIndex = 16;
            this.currentTrainingHoursLabel.Text = "Current Training Hours";
            // 
            // currTrainingHoursTextBox
            // 
            this.currTrainingHoursTextBox.Location = new System.Drawing.Point(195, 270);
            this.currTrainingHoursTextBox.Name = "currTrainingHoursTextBox";
            this.currTrainingHoursTextBox.Size = new System.Drawing.Size(100, 20);
            this.currTrainingHoursTextBox.TabIndex = 11;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(409, 432);
            this.Controls.Add(this.currTrainingHoursTextBox);
            this.Controls.Add(this.currentTrainingHoursLabel);
            this.Controls.Add(this.reqTrainingHoursTextBox);
            this.Controls.Add(this.reqTrainingHoursLabel);
            this.Controls.Add(this.leaderMonthBonusTextBox);
            this.Controls.Add(this.leaderMonthBonusLabel);
            this.Controls.Add(this.instructionsLabel);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.displayButton);
            this.Controls.Add(this.employeePayTextBox);
            this.Controls.Add(this.employeeShiftTextBox);
            this.Controls.Add(this.employeeIdTextBox);
            this.Controls.Add(this.employeeNameTextBox);
            this.Controls.Add(this.employeePayLabel);
            this.Controls.Add(this.employeeShiftLabel);
            this.Controls.Add(this.employeeIdLabel);
            this.Controls.Add(this.employeeNameLabel);
            this.Controls.Add(this.createWorkerButton);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button createWorkerButton;
        private System.Windows.Forms.Label employeeNameLabel;
        private System.Windows.Forms.Label employeeIdLabel;
        private System.Windows.Forms.Label employeeShiftLabel;
        private System.Windows.Forms.Label employeePayLabel;
        private System.Windows.Forms.TextBox employeeNameTextBox;
        private System.Windows.Forms.TextBox employeeIdTextBox;
        private System.Windows.Forms.TextBox employeeShiftTextBox;
        private System.Windows.Forms.TextBox employeePayTextBox;
        private System.Windows.Forms.Button displayButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Label instructionsLabel;
        private System.Windows.Forms.Label leaderMonthBonusLabel;
        private System.Windows.Forms.TextBox leaderMonthBonusTextBox;
        private System.Windows.Forms.Label reqTrainingHoursLabel;
        private System.Windows.Forms.TextBox reqTrainingHoursTextBox;
        private System.Windows.Forms.Label currentTrainingHoursLabel;
        private System.Windows.Forms.TextBox currTrainingHoursTextBox;
    }
}

