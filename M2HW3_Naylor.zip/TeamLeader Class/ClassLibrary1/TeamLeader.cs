﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public class TeamLeader : ProductionWorker
    {
        private int _monthBonus;
        private int _reqTrainHours;
        private int _currTrainHours;

        public TeamLeader(string name, int id, int shift, double pay, int monthBonus, int reqTrainHours, int currTrainHours) : base(name, id, shift, pay)
        {
            MonthBonus = monthBonus;
            ReqTrainHours = reqTrainHours;
            CurrTrainHours = currTrainHours;
        }

        public int MonthBonus { get { return _monthBonus; } set { _monthBonus = value; } }
        public int ReqTrainHours {  get { return _reqTrainHours; } set { _reqTrainHours = value; } }
        public int CurrTrainHours { get { return _currTrainHours; } set { _currTrainHours = value; } }
    }
}
