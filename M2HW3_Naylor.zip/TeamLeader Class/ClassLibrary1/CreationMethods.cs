﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public class CreationMethods
    { 
        public static TeamLeader CreateLeader(string name, int id, int shift, double pay, int monthBonus, int reqTrainHours, int currTrainHours)
        {
            //initialize into blanks and 0's. will be filled in through method.
            TeamLeader CurrentLeader = new TeamLeader("",0,0,0,0,0,0);

            //set information for CurrentWorker
            CurrentLeader.Name = name;
            CurrentLeader.Id = id;
            CurrentLeader.Shift = shift;
            CurrentLeader.Pay = pay;
            CurrentLeader.MonthBonus = monthBonus;
            CurrentLeader.ReqTrainHours = reqTrainHours;
            CurrentLeader.CurrTrainHours = currTrainHours;

            return CurrentLeader;
        }

    }
}
