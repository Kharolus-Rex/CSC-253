﻿namespace WinForm
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.courseCodesListBox = new System.Windows.Forms.ListBox();
            this.roomNumLabel = new System.Windows.Forms.Label();
            this.instructorLabel = new System.Windows.Forms.Label();
            this.courseTimeLabel = new System.Windows.Forms.Label();
            this.roomNumbDisplayLabel = new System.Windows.Forms.Label();
            this.instructorDisplayLabel = new System.Windows.Forms.Label();
            this.courseTimeDisplayLabel = new System.Windows.Forms.Label();
            this.courseCodeListBoxLabel = new System.Windows.Forms.Label();
            this.exitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // courseCodesListBox
            // 
            this.courseCodesListBox.FormattingEnabled = true;
            this.courseCodesListBox.Location = new System.Drawing.Point(111, 113);
            this.courseCodesListBox.Name = "courseCodesListBox";
            this.courseCodesListBox.Size = new System.Drawing.Size(120, 95);
            this.courseCodesListBox.TabIndex = 0;
            // 
            // roomNumLabel
            // 
            this.roomNumLabel.AutoSize = true;
            this.roomNumLabel.Location = new System.Drawing.Point(280, 82);
            this.roomNumLabel.Name = "roomNumLabel";
            this.roomNumLabel.Size = new System.Drawing.Size(75, 13);
            this.roomNumLabel.TabIndex = 1;
            this.roomNumLabel.Text = "Room Number";
            // 
            // instructorLabel
            // 
            this.instructorLabel.AutoSize = true;
            this.instructorLabel.Location = new System.Drawing.Point(280, 138);
            this.instructorLabel.Name = "instructorLabel";
            this.instructorLabel.Size = new System.Drawing.Size(51, 13);
            this.instructorLabel.TabIndex = 3;
            this.instructorLabel.Text = "Instructor";
            // 
            // courseTimeLabel
            // 
            this.courseTimeLabel.AutoSize = true;
            this.courseTimeLabel.Location = new System.Drawing.Point(280, 196);
            this.courseTimeLabel.Name = "courseTimeLabel";
            this.courseTimeLabel.Size = new System.Drawing.Size(71, 13);
            this.courseTimeLabel.TabIndex = 5;
            this.courseTimeLabel.Text = "Meeting Time";
            // 
            // roomNumbDisplayLabel
            // 
            this.roomNumbDisplayLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.roomNumbDisplayLabel.Location = new System.Drawing.Point(283, 105);
            this.roomNumbDisplayLabel.Name = "roomNumbDisplayLabel";
            this.roomNumbDisplayLabel.Size = new System.Drawing.Size(100, 23);
            this.roomNumbDisplayLabel.TabIndex = 6;
            // 
            // instructorDisplayLabel
            // 
            this.instructorDisplayLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.instructorDisplayLabel.Location = new System.Drawing.Point(283, 164);
            this.instructorDisplayLabel.Name = "instructorDisplayLabel";
            this.instructorDisplayLabel.Size = new System.Drawing.Size(100, 23);
            this.instructorDisplayLabel.TabIndex = 7;
            // 
            // courseTimeDisplayLabel
            // 
            this.courseTimeDisplayLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.courseTimeDisplayLabel.Location = new System.Drawing.Point(283, 222);
            this.courseTimeDisplayLabel.Name = "courseTimeDisplayLabel";
            this.courseTimeDisplayLabel.Size = new System.Drawing.Size(100, 23);
            this.courseTimeDisplayLabel.TabIndex = 8;
            // 
            // courseCodeListBoxLabel
            // 
            this.courseCodeListBoxLabel.AutoSize = true;
            this.courseCodeListBoxLabel.Location = new System.Drawing.Point(111, 94);
            this.courseCodeListBoxLabel.Name = "courseCodeListBoxLabel";
            this.courseCodeListBoxLabel.Size = new System.Drawing.Size(68, 13);
            this.courseCodeListBoxLabel.TabIndex = 9;
            this.courseCodeListBoxLabel.Text = "Course Code";
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(206, 283);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 10;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(504, 377);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.courseCodeListBoxLabel);
            this.Controls.Add(this.courseTimeDisplayLabel);
            this.Controls.Add(this.instructorDisplayLabel);
            this.Controls.Add(this.roomNumbDisplayLabel);
            this.Controls.Add(this.courseTimeLabel);
            this.Controls.Add(this.instructorLabel);
            this.Controls.Add(this.roomNumLabel);
            this.Controls.Add(this.courseCodesListBox);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox courseCodesListBox;
        private System.Windows.Forms.Label roomNumLabel;
        private System.Windows.Forms.Label instructorLabel;
        private System.Windows.Forms.Label courseTimeLabel;
        private System.Windows.Forms.Label roomNumbDisplayLabel;
        private System.Windows.Forms.Label instructorDisplayLabel;
        private System.Windows.Forms.Label courseTimeDisplayLabel;
        private System.Windows.Forms.Label courseCodeListBoxLabel;
        private System.Windows.Forms.Button exitButton;
    }
}

