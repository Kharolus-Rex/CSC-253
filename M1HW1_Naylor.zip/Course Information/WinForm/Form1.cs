﻿/**
* 9/9/2023
* CSC 253
* Connor Naylor
* This program is a demonstration of Dictionary knowledge 
* and course work.
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CreateDictionaries;

namespace WinForm
{
    public partial class Form1 : Form
    {
        public static List<string> keys;
        public Form1()
        {
            InitializeComponent();

            //creates dictionaries
            CourseDict.CreateDictions();

            //loads listbox with Keys/course codes
            keys = CourseDict.CreateKeyList();
            courseCodesListBox.Items.AddRange(keys.ToArray());

            courseCodesListBox.SelectedIndexChanged += (s, e) =>
            {
                //output course info
                string selectedCourse = courseCodesListBox.SelectedItem.ToString();

                //load labels
                if (selectedCourse != null)
                {
                    roomNumbDisplayLabel.Text = CourseDict.courseRoom[selectedCourse].ToString();
                    instructorDisplayLabel.Text = CourseDict.courseInstructor[selectedCourse].ToString();
                    courseTimeDisplayLabel.Text = CourseDict.courseTime[selectedCourse].ToString();
                }

            };
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
