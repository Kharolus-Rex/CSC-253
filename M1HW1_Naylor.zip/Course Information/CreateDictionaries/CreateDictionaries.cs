﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CreateDictionaries
{
    public class CourseDict
    {
        //initialize dictionaries
        public static Dictionary<string, int> courseRoom = new Dictionary<string, int>();
        public static Dictionary<string, string> courseInstructor = new Dictionary<string, string>();
        public static Dictionary<string, string> courseTime = new Dictionary<string, string>();
        public static void CreateDictions()
        {          
            //Add to first dictionary
            courseRoom.Add("CS101", 3004);
            courseRoom.Add("CS102", 4501);
            courseRoom.Add("CS103", 6755);
            courseRoom.Add("NT110", 1244);
            courseRoom.Add("CM241", 1411);
            //second dictionary
            courseInstructor.Add("CS101", "Haynes");
            courseInstructor.Add("CS102", "Alvarado");
            courseInstructor.Add("CS103", "Rich");
            courseInstructor.Add("NT110", "Burke");
            courseInstructor.Add("CM241", "Lee");
            //third dictionary
            courseTime.Add("CS101", "8:00 AM");
            courseTime.Add("CS102", "9:00 AM");
            courseTime.Add("CS103", "10:00 AM");
            courseTime.Add("NT110", "11:00 AM");
            courseTime.Add("CM241", "1:00 PM");
        }
        //need a list for Keys
        public static List<string> CreateKeyList()
        {
            List<string> keys = new List<string>();

            keys.Add("CS101");
            keys.Add("CS102");
            keys.Add("CS103");
            keys.Add("NT110");
            keys.Add("CM241");

            return keys;
        }
    }
}
