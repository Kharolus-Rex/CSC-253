﻿/**
* 9/27/23
* CSC 253
* Connor Naylor
* This is a simple program to demonstrate inheritance for classes.
* User inputs data, the program creates a ShiftSupervisor object from the data.
* Name and ID arguments are derived from superclass Employee.
* Display button lets user verify information.
* This was essentially a copy/paste from the previous homework. Drill the lesson, I suppose.
*/

using ClassLibrary1;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinForm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        public ShiftSupervisor currentSupervisor;

        private void createWorkerButton_Click(object sender, EventArgs e)
        {
            //assign values to variables for method call
            string employeeName = employeeNameTextBox.Text;
            int employeeId = int.Parse(employeeIdTextBox.Text);
            int employeeShift = int.Parse(employeeShiftTextBox.Text);
            int employeePay = int.Parse(employeePayTextBox.Text);
            int supervisorBonus = int.Parse(supervisorBonusTextBox.Text);

            //method call
            currentSupervisor = CreationMethods.CreateSupervisor(employeeName, employeeId, employeeShift, employeePay, supervisorBonus);

            MessageBox.Show("Employee created.");
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void displayButton_Click(object sender, EventArgs e)
        {
            //simple message box to verify that information displays
            MessageBox.Show($"Employee Name: {currentSupervisor.Name} \nEmployee ID: {currentSupervisor.Id} \nEmployee Shift: {currentSupervisor.Shift} \nAnnual Salary: ${currentSupervisor.Salary} \nAnnual Bonus: ${currentSupervisor.Bonus}");
        }
    }
}
