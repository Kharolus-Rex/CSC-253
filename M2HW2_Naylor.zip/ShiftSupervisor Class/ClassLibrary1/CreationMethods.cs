﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public class CreationMethods
    { 
        public static ShiftSupervisor CreateSupervisor(string name, int id, int shift, int salary, int bonus)
        {
            //initialize into blanks and 0's. will be filled in through method.
            ShiftSupervisor CurrentSupervisor = new ShiftSupervisor("",0,0,0,0);

            //set information for CurrentWorker
            CurrentSupervisor.Name = name;
            CurrentSupervisor.Id = id;
            CurrentSupervisor.Shift = shift;
            CurrentSupervisor.Salary = salary;
            CurrentSupervisor.Bonus = bonus;

            return CurrentSupervisor;
        }

    }
}
