﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public class ShiftSupervisor : Employee
    {
        private int _shift;
        private int _salary;
        private int _bonus;

        public ShiftSupervisor(string name, int id, int shift, int salary, int bonus) : base(name, id)
        {
            Shift = shift;
            Salary = salary;
            Bonus = bonus;
        }

        public int Shift { get { return _shift; } set { _shift = value; } }
        public int Salary { get { return _salary; } set { _salary = value; } }
        public int Bonus { get { return _bonus; } set { _bonus = value; } }
    }
}
