﻿/**
* 10/22/23
* CSC 253
* Connor Naylor
* This is a program designed to test knowledge of
* database access and utilization. It will read data from
* a database (SQLite file) and load it into a list, then
* into a DataGridView for user to see.
*/

using MethodCalls;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinForm
{
    public partial class Form1 : Form
    {

        List<EmployeeModel> employee = new List<EmployeeModel>();

        public Form1()
        {
            InitializeComponent();

            LoadEmployeeList();
        }

        private void LoadEmployeeList()
        {
            employee = SqliteDataAccess.LoadEmployees();

            LoadDataGrid();
        }

        private void LoadDataGrid()
        {
            //empty the datasource first and then load
            employeeDataGridView.DataSource = null;
            employeeDataGridView.DataSource = employee;
            
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
