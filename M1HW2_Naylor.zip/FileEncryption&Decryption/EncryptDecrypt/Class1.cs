﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Collections;

namespace EncryptDecrypt
{
    public class Cryption
    {
        //encrypt/decrypt dictionaries should exist outside of methods?
        //SPACES ARE PRESERVED BOTH WAYS WITH KEY H

        public static void Encryption(string inputFilePath, string outputFilePath)
        {
            Dictionary<char, char> EncryptAlgo = new Dictionary<char, char>()
            {
                { 'A', '1' }, { 'a', '!' },
                { 'B', '2' }, { 'b', '@' },
                { 'C', '3' }, { 'c', '#' },
                { 'D', '4' }, { 'd', '$' },
                { 'E', '5' }, { 'e', '%' },
                { 'F', '6' }, { 'f', '^' },
                { 'G', '7' }, { 'g', '&' },
                { 'H', '8' }, { 'h', '*' },
                { 'I', '9' }, { 'i', '(' },
                { 'J', '0' }, { 'j', ')' },
                { 'K', '-' }, { 'k', '_' },
                { 'L', '=' }, { 'l', '+' },
                { 'M', '[' }, { 'm', '{' },
                { 'N', ']' }, { 'n', '}' },
                { 'O', '\\' }, { 'o', '|' },
                { 'P', ';' }, { 'p', ':' },
                { 'Q', '\'' }, { 'q', '"' },
                { 'R', ',' }, { 'r', '<' },
                { 'S', '.' }, { 's', '>' },
                { 'T', '/' }, { 't', '?' },
                { 'U', '`' }, { 'u', '~' },
                { 'V', 'Q' }, { 'v', 'q' },
                { 'W', 'A' }, { 'w', 'a' },
                { 'X', 'Z' }, { 'x', 'z' },
                { 'Y', 'W' }, { 'y', 'w' },
                { 'Z', 'S' }, { 'z', 's' }

            };
            //I need it to read all lines and pop into an array
            //in the event that there are multiple lines
            string[] lines = File.ReadAllLines(inputFilePath);

            using (StreamWriter outputFile = new StreamWriter(outputFilePath))
            {
                //per line run
                foreach (string line in lines)
                {
                    //encrypt each line
                    foreach (char c in line)
                    {
                        if (EncryptAlgo.ContainsKey(c))
                        {
                            //replace characters
                            outputFile.Write(EncryptAlgo[c]);
                        }
                        else
                        {
                            //keep non-encrypted characters. I added space as an encryptions for the hell of it.
                            outputFile.Write(c);
                        }
                    }
                    //write a blank line between lines for readability.
                    //outputFile.WriteLine();
                }
                //closes file once done writing
                outputFile.Close();
            }
            return;
        }

        public static void Decryption(string inputFilePath, string outputFilePath)
        {
            Dictionary<char, char> DecryptAlgo = new Dictionary<char, char>()
            {
                { '1', 'A' }, { '!', 'a' },
                { '2', 'B' }, { '@', 'b' },
                { '3', 'C' }, { '#', 'c' },
                { '4', 'D' }, { '$', 'd' },
                { '5', 'E' }, { '%', 'e' },
                { '6', 'F' }, { '^', 'f' },
                { '7', 'G' }, { '&', 'g' },
                { '8', 'H' }, { '*', 'h' },
                { '9', 'I' }, { '(', 'i' },
                { '0', 'J' }, { ')', 'j' },
                { '-', 'K' }, { '_', 'k' },
                { '=', 'L' }, { '+', 'l' },
                { '[', 'M' }, { '{', 'm' },
                { ']', 'N' }, { '}', 'n' },
                { '\\', 'O' }, { '|', 'o' },
                { ';', 'P' }, { ':', 'p' },
                { '\'', 'Q' }, { '"', 'q' },
                { ',', 'R' }, { '<', 'r' },
                { '.', 'S' }, { '>', 's' },
                { '/', 'T' }, { '?', 't' },
                { '`', 'U' }, { '~', 'u' },
                { 'Q', 'V' }, { 'q', 'v' },
                { 'A', 'W' }, { 'a', 'w' },
                { 'Z', 'X' }, { 'z', 'x' },
                { 'W', 'Y' }, { 'w', 'y' },
                { 'S', 'Z' }, { 's', 'z' }

            };
        //It's literally just the same thing but with the decryptionAlgo
        string[] lines = File.ReadAllLines(inputFilePath);

            using (StreamWriter outputFile = new StreamWriter(outputFilePath))
            {
                //per line run
                foreach (string line in lines)
                {
                    //encrypt each line
                    foreach (char c in line)
                    {
                        if (DecryptAlgo.ContainsKey(c))
                        {
                            //replace characters
                            outputFile.Write(DecryptAlgo[c]);
                        }
                        else
                        {
                            //keep non-encrypted characters. I added space as an encryptions for the hell of it.
                            outputFile.Write(c);
                        }
                    }
                    //write a blank line between lines for readability.
                    //outputFile.WriteLine();
                }
                //closes file once done writing
                outputFile.Close();
            }
            return;
        }
    }
}
