﻿/**
* 9/10/23
* CSC 253
* Connor Naylor
* This program demonstrates simple asymetric 
* encryption and decryption of text files.
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using EncryptDecrypt;

namespace WinForm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void encryptButton_Click(object sender, EventArgs e)
        {
            string inputFilePath;

            string outputFilePath;

            openFileDialog1.ShowDialog(); //get file to encrypt

            inputFilePath = openFileDialog1.FileName.ToString();

            saveFileDialog1.ShowDialog(); //get encrypted save location

            outputFilePath = saveFileDialog1.FileName.ToString();

            //if statement in the event that user accidentially or purposefully
            //doesn't choose an input or output file
            //if (!string.IsNullOrEmpty(inputFilePath) && !string.IsNullOrEmpty(outputFilePath))
            //{
                Cryption.Encryption(inputFilePath, outputFilePath);
            //}

        }

        private void decryptButton_Click(object sender, EventArgs e)
        {
            string inputFilePath;

            string outputFilePath;

            openFileDialog1.ShowDialog(); //get file to decrypt

            inputFilePath = openFileDialog1.FileName;

            saveFileDialog1.ShowDialog(); //get encrypted save location

            outputFilePath = saveFileDialog1.FileName;

            //if (!string.IsNullOrEmpty(inputFilePath) && !string.IsNullOrEmpty(outputFilePath))
            //{
                Cryption.Decryption(inputFilePath, outputFilePath);
            //}
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
