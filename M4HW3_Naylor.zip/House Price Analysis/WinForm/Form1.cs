﻿/**
* 11/5/23
* CSC 253
* Connor Naylor
* This doozy of a program utilizes a csv file to display
* a list of homes and their price, bedrooms, bathrooms, and sq ft.
* Allowing for input, a user may filter the list to suit what they need.
*/

using MethodsNMadness;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinForm
{
    public partial class Form1 : Form
    {
        public List<HouseData> houseDataList = new List<HouseData>();

        public Form1()
        {
            InitializeComponent();

            LoadHouseData();
        }

        private void LoadHouseData()
        {
            houseDataList = SimpleMethods.LoadHouseCSVData();

            LoadDataList(houseDataList);
        }

        private void LoadDataList(List<HouseData> dataList, SimpleMethods.HouseFilter filter = null)
        {
            houseDataListBox.Items.Clear(); //clear any possible entries on load

            foreach (var houseData in dataList)
            {
                //validate that incoming data is in fact a HouseData object type
                if (filter == null || filter(houseData))
                {
                    // I forgot for a minute that a listbox needs a string or a list of things to add to it. Not a datagrid that I can load a list into.
                    string display = $"Price: {houseData.Price}, Bedrooms: {houseData.Bedrooms}, Bathrooms: {houseData.Bathrooms}, Square Ft: {houseData.SqFt}";
                    houseDataListBox.Items.Add(display);
                }
            }
        }

        private void filterButton_Click(object sender, EventArgs e)
        {
            //user inputed data. 
            int minBedrooms = int.Parse(bedroomMinTextBox.Text);
            int maxBedrooms = int.Parse(bedroomMaxTextBox.Text);
            double minBathrooms = double.Parse(bathroomMinTextBox.Text);
            double maxBathrooms = double.Parse(bathroomMaxTextBox.Text);
            int minSqFt = int.Parse(sqFtMinTextBox.Text);
            int maxSqFt = int.Parse(sqFtMaxTextBox.Text);

            //create filter
            SimpleMethods.HouseFilter filter = SimpleMethods.CreateFilter(minBedrooms, maxBedrooms, minBathrooms, maxBathrooms, minSqFt, maxSqFt);

            List<HouseData> filteredList = SimpleMethods.FilterHouses(houseDataList, filter);

            LoadDataList(filteredList);
        }

        private void resetButton_Click(object sender, EventArgs e)
        {
            houseDataListBox.Items.Clear(); //clear entries
            LoadDataList(houseDataList); //this loads the inital list
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
