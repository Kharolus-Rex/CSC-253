﻿namespace WinForm
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.houseDataListBox = new System.Windows.Forms.ListBox();
            this.bedroomMinTextBox = new System.Windows.Forms.TextBox();
            this.bedroomMaxTextBox = new System.Windows.Forms.TextBox();
            this.bedroomMinLabel = new System.Windows.Forms.Label();
            this.bedroomMaxLabel = new System.Windows.Forms.Label();
            this.bathroomMinLabel = new System.Windows.Forms.Label();
            this.bathroomsMaxLabel = new System.Windows.Forms.Label();
            this.bathroomMinTextBox = new System.Windows.Forms.TextBox();
            this.bathroomMaxTextBox = new System.Windows.Forms.TextBox();
            this.sqFtMinLabel = new System.Windows.Forms.Label();
            this.sqFtMaxLabel = new System.Windows.Forms.Label();
            this.sqFtMinTextBox = new System.Windows.Forms.TextBox();
            this.sqFtMaxTextBox = new System.Windows.Forms.TextBox();
            this.filterButton = new System.Windows.Forms.Button();
            this.resetButton = new System.Windows.Forms.Button();
            this.instructionsLabel = new System.Windows.Forms.Label();
            this.exitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // houseDataListBox
            // 
            this.houseDataListBox.FormattingEnabled = true;
            this.houseDataListBox.Location = new System.Drawing.Point(338, 74);
            this.houseDataListBox.Name = "houseDataListBox";
            this.houseDataListBox.Size = new System.Drawing.Size(351, 225);
            this.houseDataListBox.TabIndex = 0;
            // 
            // bedroomMinTextBox
            // 
            this.bedroomMinTextBox.Location = new System.Drawing.Point(67, 155);
            this.bedroomMinTextBox.Name = "bedroomMinTextBox";
            this.bedroomMinTextBox.Size = new System.Drawing.Size(100, 20);
            this.bedroomMinTextBox.TabIndex = 1;
            // 
            // bedroomMaxTextBox
            // 
            this.bedroomMaxTextBox.Location = new System.Drawing.Point(189, 155);
            this.bedroomMaxTextBox.Name = "bedroomMaxTextBox";
            this.bedroomMaxTextBox.Size = new System.Drawing.Size(100, 20);
            this.bedroomMaxTextBox.TabIndex = 2;
            // 
            // bedroomMinLabel
            // 
            this.bedroomMinLabel.AutoSize = true;
            this.bedroomMinLabel.Location = new System.Drawing.Point(64, 139);
            this.bedroomMinLabel.Name = "bedroomMinLabel";
            this.bedroomMinLabel.Size = new System.Drawing.Size(98, 13);
            this.bedroomMinLabel.TabIndex = 3;
            this.bedroomMinLabel.Text = "Minimum Bedrooms";
            // 
            // bedroomMaxLabel
            // 
            this.bedroomMaxLabel.AutoSize = true;
            this.bedroomMaxLabel.Location = new System.Drawing.Point(186, 139);
            this.bedroomMaxLabel.Name = "bedroomMaxLabel";
            this.bedroomMaxLabel.Size = new System.Drawing.Size(101, 13);
            this.bedroomMaxLabel.TabIndex = 4;
            this.bedroomMaxLabel.Text = "Maximum Bedrooms";
            // 
            // bathroomMinLabel
            // 
            this.bathroomMinLabel.AutoSize = true;
            this.bathroomMinLabel.Location = new System.Drawing.Point(64, 183);
            this.bathroomMinLabel.Name = "bathroomMinLabel";
            this.bathroomMinLabel.Size = new System.Drawing.Size(101, 13);
            this.bathroomMinLabel.TabIndex = 5;
            this.bathroomMinLabel.Text = "Minimum Bathrooms";
            // 
            // bathroomsMaxLabel
            // 
            this.bathroomsMaxLabel.AutoSize = true;
            this.bathroomsMaxLabel.Location = new System.Drawing.Point(186, 183);
            this.bathroomsMaxLabel.Name = "bathroomsMaxLabel";
            this.bathroomsMaxLabel.Size = new System.Drawing.Size(104, 13);
            this.bathroomsMaxLabel.TabIndex = 6;
            this.bathroomsMaxLabel.Text = "Maximum Bathrooms";
            // 
            // bathroomMinTextBox
            // 
            this.bathroomMinTextBox.Location = new System.Drawing.Point(67, 199);
            this.bathroomMinTextBox.Name = "bathroomMinTextBox";
            this.bathroomMinTextBox.Size = new System.Drawing.Size(100, 20);
            this.bathroomMinTextBox.TabIndex = 7;
            // 
            // bathroomMaxTextBox
            // 
            this.bathroomMaxTextBox.Location = new System.Drawing.Point(189, 199);
            this.bathroomMaxTextBox.Name = "bathroomMaxTextBox";
            this.bathroomMaxTextBox.Size = new System.Drawing.Size(100, 20);
            this.bathroomMaxTextBox.TabIndex = 8;
            // 
            // sqFtMinLabel
            // 
            this.sqFtMinLabel.AutoSize = true;
            this.sqFtMinLabel.Location = new System.Drawing.Point(64, 222);
            this.sqFtMinLabel.Name = "sqFtMinLabel";
            this.sqFtMinLabel.Size = new System.Drawing.Size(76, 13);
            this.sqFtMinLabel.TabIndex = 9;
            this.sqFtMinLabel.Text = "Minimum Sq Ft";
            // 
            // sqFtMaxLabel
            // 
            this.sqFtMaxLabel.AutoSize = true;
            this.sqFtMaxLabel.Location = new System.Drawing.Point(188, 222);
            this.sqFtMaxLabel.Name = "sqFtMaxLabel";
            this.sqFtMaxLabel.Size = new System.Drawing.Size(79, 13);
            this.sqFtMaxLabel.TabIndex = 10;
            this.sqFtMaxLabel.Text = "Maximum Sq Ft";
            // 
            // sqFtMinTextBox
            // 
            this.sqFtMinTextBox.Location = new System.Drawing.Point(67, 238);
            this.sqFtMinTextBox.Name = "sqFtMinTextBox";
            this.sqFtMinTextBox.Size = new System.Drawing.Size(100, 20);
            this.sqFtMinTextBox.TabIndex = 11;
            // 
            // sqFtMaxTextBox
            // 
            this.sqFtMaxTextBox.Location = new System.Drawing.Point(187, 238);
            this.sqFtMaxTextBox.Name = "sqFtMaxTextBox";
            this.sqFtMaxTextBox.Size = new System.Drawing.Size(100, 20);
            this.sqFtMaxTextBox.TabIndex = 12;
            // 
            // filterButton
            // 
            this.filterButton.Location = new System.Drawing.Point(77, 276);
            this.filterButton.Name = "filterButton";
            this.filterButton.Size = new System.Drawing.Size(75, 23);
            this.filterButton.TabIndex = 13;
            this.filterButton.Text = "Filter";
            this.filterButton.UseVisualStyleBackColor = true;
            this.filterButton.Click += new System.EventHandler(this.filterButton_Click);
            // 
            // resetButton
            // 
            this.resetButton.Location = new System.Drawing.Point(202, 276);
            this.resetButton.Name = "resetButton";
            this.resetButton.Size = new System.Drawing.Size(75, 23);
            this.resetButton.TabIndex = 14;
            this.resetButton.Text = "Reset";
            this.resetButton.UseVisualStyleBackColor = true;
            this.resetButton.Click += new System.EventHandler(this.resetButton_Click);
            // 
            // instructionsLabel
            // 
            this.instructionsLabel.Location = new System.Drawing.Point(64, 74);
            this.instructionsLabel.Name = "instructionsLabel";
            this.instructionsLabel.Size = new System.Drawing.Size(226, 55);
            this.instructionsLabel.TabIndex = 15;
            this.instructionsLabel.Text = "Please enter values to filter by. Click filter to filter the list, or click Reset" +
    " to return the list to its original state.";
            this.instructionsLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(139, 305);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 16;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 416);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.instructionsLabel);
            this.Controls.Add(this.resetButton);
            this.Controls.Add(this.filterButton);
            this.Controls.Add(this.sqFtMaxTextBox);
            this.Controls.Add(this.sqFtMinTextBox);
            this.Controls.Add(this.sqFtMaxLabel);
            this.Controls.Add(this.sqFtMinLabel);
            this.Controls.Add(this.bathroomMaxTextBox);
            this.Controls.Add(this.bathroomMinTextBox);
            this.Controls.Add(this.bathroomsMaxLabel);
            this.Controls.Add(this.bathroomMinLabel);
            this.Controls.Add(this.bedroomMaxLabel);
            this.Controls.Add(this.bedroomMinLabel);
            this.Controls.Add(this.bedroomMaxTextBox);
            this.Controls.Add(this.bedroomMinTextBox);
            this.Controls.Add(this.houseDataListBox);
            this.Name = "Form1";
            this.Text = "House Price Analysis";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox houseDataListBox;
        private System.Windows.Forms.TextBox bedroomMinTextBox;
        private System.Windows.Forms.TextBox bedroomMaxTextBox;
        private System.Windows.Forms.Label bedroomMinLabel;
        private System.Windows.Forms.Label bedroomMaxLabel;
        private System.Windows.Forms.Label bathroomMinLabel;
        private System.Windows.Forms.Label bathroomsMaxLabel;
        private System.Windows.Forms.TextBox bathroomMinTextBox;
        private System.Windows.Forms.TextBox bathroomMaxTextBox;
        private System.Windows.Forms.Label sqFtMinLabel;
        private System.Windows.Forms.Label sqFtMaxLabel;
        private System.Windows.Forms.TextBox sqFtMinTextBox;
        private System.Windows.Forms.TextBox sqFtMaxTextBox;
        private System.Windows.Forms.Button filterButton;
        private System.Windows.Forms.Button resetButton;
        private System.Windows.Forms.Label instructionsLabel;
        private System.Windows.Forms.Button exitButton;
    }
}

