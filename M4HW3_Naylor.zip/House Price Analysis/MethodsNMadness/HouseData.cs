﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MethodsNMadness
{
    public class HouseData
    {
        private int _price;
        private int _bedrooms;
        private double _bathrooms;
        private int _sqFt;

        public HouseData(int price,  int bedrooms, double bathrooms, int sqFt)
        {
            Price = price;
            Bedrooms = bedrooms;
            Bathrooms = bathrooms;
            SqFt = sqFt;
        }

        public int Price { get { return _price; } set { _price = value; } }
        public int Bedrooms { get { return _bedrooms; } set { _bedrooms = value; } }
        public double Bathrooms { get { return _bathrooms; } set { _bathrooms = value; } }
        public int SqFt { get { return _sqFt; } set { _sqFt = value; } }
    }
}
