﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace MethodsNMadness
{
    public class SimpleMethods
    {
        public delegate bool HouseFilter(HouseData house);
        public static List<HouseData> LoadHouseCSVData()
        {
            List<HouseData> dataList = new List<HouseData>();

            using (var reader = new StreamReader(@"..\..\..\MethodsNMadness\house_prices.csv"))
            {
                while (!reader.EndOfStream)
                {
                    var row = reader.ReadLine().Split(',');

                    int price = int.Parse(row[0]);
                    int bedrooms = int.Parse(row[1]);
                    double bathrooms = double.Parse(row[2]);
                    int sqft = int.Parse(row[3]);

                    HouseData house = new HouseData(price, bedrooms, bathrooms, sqft);

                    dataList.Add(house);
                }
            }

            return dataList;

        }

        public static HouseFilter CreateFilter(int minBedrooms, int maxBedrooms, double minBathrooms, double maxBathrooms, int minSqFt, int maxSqFt)
        {
            return house =>
            {
                return house.Bedrooms >= minBedrooms && house.Bedrooms <= maxBedrooms &&
                house.Bathrooms >= minBathrooms && house.Bathrooms <= maxBathrooms &&
                house.SqFt >= minSqFt && house.SqFt <= maxSqFt;
            };
        }

        public static List<HouseData> FilterHouses(List<HouseData> dataList, HouseFilter filter)
        {
            List<HouseData> filteredList = new List<HouseData>();

            foreach (var houseData in dataList)
            {
                if (filter(houseData))
                {
                    filteredList.Add(houseData);
                }
            }

            return filteredList;
        }
    }
}
